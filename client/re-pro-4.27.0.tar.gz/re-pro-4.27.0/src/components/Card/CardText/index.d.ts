export { default } from './CardText';
export * from './CardText';