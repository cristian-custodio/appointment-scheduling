import * as React from "react";

declare const MDBCardTitle: React.FunctionComponent<{
  className?: string;
  sub?: boolean;
  tag?: string;
  [rest: string]: any;
}>;

export default MDBCardTitle;
