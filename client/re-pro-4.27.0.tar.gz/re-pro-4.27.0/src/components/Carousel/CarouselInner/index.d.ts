export { default } from './CarouselInner';
export * from './CarouselInner';