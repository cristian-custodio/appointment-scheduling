import * as React from "react";

declare class MDBCarouselInner extends React.Component<{
  active?: boolean;
  className?: string;
  childrenCount?: number;
  children?: React.ReactNode;
  tag?: string;
  [rest: string]: any;
}, any> {}

export default MDBCarouselInner;
