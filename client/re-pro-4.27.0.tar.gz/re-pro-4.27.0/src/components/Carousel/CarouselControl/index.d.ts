export { default } from './CarouselControl';
export * from './CarouselControl';