import * as React from "react";

declare const MDBHamburgerToggler: React.FunctionComponent<{
  color?: string;
  className?: string;
  id?: string;
  [rest: string]: any;
}>;

export default MDBHamburgerToggler;
