export { default } from './Fa';
export * from './Fa';